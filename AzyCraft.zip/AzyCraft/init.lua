minetest.register_node("AzyCraftf:meme", {
  description = "Piece of Trash",
  tiles = {"pixil-frame-0.png"},
	groups = {snappy=1,choppy=2,oddly_breakable_by_hand=2,flammable=3},
})

minetest.register_craft({
  type = "shapeless",
	output = 'AzyCraft:meme 1',
	recipe = {"default:dirt","default:dirt"},
	

})

minetest.register_node("AzyCraft:glass", {
	description = "Blue Glass",
	tiles = {"pixil-frame-1.png"},
	drawtype = "glasslike",
	paramtype = "light",
	sunlight_propagates = true,
	use_texture_alpha = true,
	groups = {snappy=1,choppy=2,oddly_breakable_by_hand=2},
})

minetest.register_craft({
  type = "shapeless",
	output = 'AzyCraft:glass 1',
	recipe = {"default:sand","default:sand"},
	
})

minetest.register_node("AzyCraft:brick", {
  description = "Blue Brick",
  tiles = {"pixil-frame-3.png"},
	groups = {snappy=1,choppy=2,oddly_breakable_by_hand=2},
})

minetest.register_craft({
  type = "shapeless",
	output = 'AzyCraft:brick 1',
	recipe = {"default:stone","default:stone"},
	

})

minetest.register_node("AzyCraft:bbrick", {
  description = "Blue Thin Brick",
  tiles = {"pixil-frame-2.png"},
	groups = {snappy=1,choppy=2,oddly_breakable_by_hand=2},
})

minetest.register_craft({
  type = "shapeless",
	output = 'AzyCraft:bbrick 1',
	recipe = {"default:stone","default:stone"},
	

})
